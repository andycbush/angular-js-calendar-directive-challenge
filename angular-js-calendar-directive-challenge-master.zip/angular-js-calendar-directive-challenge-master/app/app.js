angular.module('calendarDemoApp', []);

// your controller and directive code go here